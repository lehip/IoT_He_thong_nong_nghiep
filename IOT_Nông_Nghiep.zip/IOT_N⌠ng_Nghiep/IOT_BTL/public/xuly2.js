var socket = io("http://localhost:6060")

socket.on("server-update-data", function (data) {
    
    document.getElementById("#id-content").append("<div class='h-paha'>" + data.id + "</div>")
    document.getElementById("#time-content").append("<div class='h-paha'>" + data.time + "</div>")
    document.getElementById("#temp-content").append("<div class='h-paha'>" + data.temp + "</div>")
    document.getElementById("#humi-content").append("<div class='h-paha'>" + data.humi + "</div>")
    document.getElementById("#humi-content").append("<div class='h-paha'>" + data.light + "</div>")
 }
)


