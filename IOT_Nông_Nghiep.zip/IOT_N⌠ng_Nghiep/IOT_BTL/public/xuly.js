var socket = io("http://localhost:6060")

socket.on("server-update-data", function (data) {
    // Home page
    document.getElementById("Nhietdo").innerText = data.temp +'°C';
    document.getElementById("Doam").innerText = data.humi + '%'; 
    document.getElementById("Doamdat").innerText = data.doam + '%'; 
    document.getElementById("Anhsang").innerText = data.light +  ' lux';


//---------------------------Hàm cảnh báo ----------------------------
    // var warningSection1
    // warningSection1 = document.getElementById("warningSection1");
    if ( data.temp < 10 ) {
        document.getElementById("warningSection1").style.background="#E6A19F"; 
        //alert("Nhiệt độ quá thấp !!!!")
    } else if ( data.temp < 20) {
        document.getElementById("warningSection1").style.background="#F17B78";

    }else if ( data.temp < 33) {
        document.getElementById("warningSection1").style.background="#FF6A6A";
       // alert("Nhiệt độ bình thường")
    }else{
        document.getElementById("warningSection1").style.background=" #EE3030";
        //alert("Warning:Nhiệt độ quá cao")
    }
    
    // var warningSection2
    // warningSection2 = document.getElementById("warningSection2");
    if (data.humi < 30 ) {
        document.getElementById("warningSection2").style.background= "#00CDCD"; // #00CDCD
        //comfrim("Độ ẩm thấp !")
    } else if(data.humi > 31 && data.humi < 70){
        document.getElementById("warningSection2").style.background ="#00EEEE";
    }else{
        document.getElementById("warningSection2").style.background="#00FFFF";
    }
    
    if (data.doam < 60) {
      document.getElementById("warningSection3").style.background= "#FFC0CB";
      alert("Độ ẩm đã đạt ");
    } else if(data.doam > 60 && data.doam < 75){
      // notifySoil();
      document.getElementById("warningSection3").style.background ="#FF69B4";
      }else{
      document.getElementById("warningSection3").style.background="#FF1493";
    }
   

    // var warningSection3 = document.getElementById("warningSection3");
    if (data.light < 200 ) {
       // alert('Ánh sáng kém !');
        document.getElementById("warningSection3").style.background= "#FFC0CB";
       
    } else if(data.light > 200 && data.light < 900){
        document.getElementById("warningSection3").style.background ="#FF69B4";

    }else{
        document.getElementById("warningSection3").style.background="#FF1493";

    }
})

function notifySoil() {
  alert("Độ ẩm tốt rồi tắt ngưỡng máy bơm đi");
}


//------------------------Đồ thị hight chart --------------------------

var chart = Highcharts.chart('container', {
    chart: {
        zoomType: 'xy'
    },
        title: {
        text: 'Đồ thị nhiệt độ - độ ẩm - ánh sáng'
    },
  
    xAxis: [{
        categories: [], //Khai báo từ 1 đến 20 giá trị trên biểu đồ
        tickWidth: 1,
        tickLength: 20
    }],
    yAxis: [{ // Primary yAxis
          // Secondary yAxis
        title: {
            text: 'Độ ẩm(%)',
            style: {
                    color: Highcharts.getOptions().colors[0]
            }
        },
            labels: {
                format: '{value}',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
           
        },{
        title: {
            text: 'Nhiệt độ (°C)',
            style: {
                color: Highcharts.getOptions().colors[1]
            }
    },  
        labels: {
        format: '{value}',
        style: {
            color: Highcharts.getOptions().colors[1]
        }
        
    },
    },{ // Secondary yAxis
       title: {
           text: 'Ánh sáng(Lux)',
           style: {
              color: Highcharts.getOptions().colors[2]
         }
       },
        labels: {
             format: '{value}',
             style: {
                color: Highcharts.getOptions().colors[2]
             }
         },
        opposite: true
    },{ 
        title: {
            text: 'Độ ẩm đất(%)',
            style: {
                color: Highcharts.getOptions().colors[3]
        }
    },
        labels: {
            format: '{value}',
            style: {
                color: Highcharts.getOptions().colors[3]
            }
        },
       
    }],
    tooltip: {
        shared: true
    },
    legend: {
        layout: 'vertical',
        align: 'left', // left
        x: 1000,
        verticalAlign: 'top', 
        y: 120,
        floating: true,
        backgroundColor:
            Highcharts.defaultOptions.legend.backgroundColor || // theme
            'rgba(255,255,255,0.25)'
    },
    series: [{
        name: 'Độ ẩm',
        type: 'line', //spline: kiểu đường //column : kiểu cột // pie: kiểu hình tròn
        //yAxis: 1,
        data: [],
        tooltip: {
            valueSuffix: '%'
        },
        color:'yellow',
  
    }, {
        name: 'Nhiệt độ',
        type: 'line',
        data: [],
        tooltip: {
          valueSuffix: '°C' 
      },
       color:'blue',
    },{
        name: 'Ánh sáng',
        type: 'line',
        data: [],
        tooltip: {
          valueSuffix: 'lux'
      },
       color:'pink',
 
    },{
        name: 'Độ ẩm đất',
        type: 'line',
        data: [],
        tooltip: {
          valueSuffix: '%' 
      },
       color:'red',
    }],
  });
  
var humi = [];
var temp = [];
var light =  [];
var soil =  [];
  

  socket.on("server-send-humi_graph", function (data) {
    chart.series[0].setData(data);
  });
  
  socket.on("server-send-temp_graph", function (data) {
    chart.series[1].setData(data);
  });

  socket.on("server-send-light_graph", function (data) {
   chart.series[2].setData(data);
  });

  socket.on("server-send-soil_graph", function (data) {
    chart.series[3].setData(data);
   });

  socket.on("server-send-date_graph", function (data) {
    chart.xAxis[0].setCategories(data);
  });
  

// --------------------- Hàm đồng đồ hiển thị -----------------
var timeDisplay = document.getElementById("time");

function refreshTime() {
    var dateString = new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" });
    var formattedString = dateString.replace(", ", " - ");
    timeDisplay.innerHTML = formattedString;
}

setInterval(refreshTime, 1000);


//----------------function để bật tắt đèn ---------------
function ClickOn1(){
    if( confirm('Bạn có muốn bật đèn hay không') == true){
    socket.emit("Led1",'on');
    document.getElementById("background1").style.background="blue";
    document.getElementById("myImage").src="./led.png";
   }
  }
  
  function ClickOff1(){  
    if( confirm('Bạn có muốn tắt đèn hay không ?') == true){ 
    socket.emit("Led1",'off')
    document.getElementById("background1").style.background="rgb(167, 66, 66)";
    document.getElementById("myImage").src= "./ledoff.png";
  }
  }
  
function ClickOn2(){
    if( confirm('Bạn có muốn bật máy bơm nước hay không') == true){
    socket.emit("Led2",'on');
    document.getElementById('min').style.background ="red";
    document.getElementById('dh').src='./wateron.png';
  }
}
function ClickOff2(){
    if( confirm('Bạn có muốn tắt máy bơm nước hay không') == true){
    socket.emit("Led2",'off');
    document.getElementById('min').style.background = "rgb(157, 255, 0)";
    document.getElementById('dh').src='./wateroff.png';
 }
}

//-----------------------------Hàm setup ngưỡng------------------------------------
var nguongNhietDo = null;
var nguongDoAm = null;

function setNguongNhietDo() {
    alert("Đã thiết lập ngưỡng nhiệt độ !")
    nguongNhietDo = parseInt(document.getElementById("inputNhietDo").value);
    socket.on("server-update-data", function (data) {

    if (data.light < nguongNhietDo)
    {
        //alert("Nhiệt độ thấp");
        socket.emit("Led1", 'on')
        document.getElementById("background1").style.background="blue";
        document.getElementById("myImage").src="./led.png";
        print("Nhiệt độ dưới ngưỡng, bật đèn, bật máy bơm");    
    } 
    
    console.log("Ngưỡng nhiệt độ: " + nguongNhietDo + " độ C");
   })
}

function setTatNguongNhietDo() {
    alert('Tắt ngưỡng nhé !')
    // tắt ngưỡng nhiệt độ
    nguongNhietDo = document.getElementById("inputNhietDo").value = ' ';
    socket.emit("Led1",'off')
    document.getElementById("background1").style.background="rgb(167, 66, 66)";
    document.getElementById("myImage").src= "./ledoff.png";
}


function setNguongDoAmDat() {
    alert("Đã thiết lập ngưỡng độ ẩm!")
    nguongDoAm = parseInt(document.getElementById("inputDoAmDat").value);
  
    socket.on("server-update-data", function (data) {
 
    if (data.doam < nguongDoAm)
    {
        On2();
        print("Nhiệt độ dưới ngưỡng bật máy bơm");
    }

    // if (data.doam < 80){
    //   alert("Độ ẩm đã đặt tốt hãy tắt ngưỡng máy bơm đi !");
    // } else {
    // }

    console.log("Ngưỡng độ ẩm: " + nguongDoAm + "%");
   })
}


function setTatNguongDoAm() {
    // tắt ngưỡng độ ẩm
    alert("Tắt ngưỡng nhé !")
    nguongDoAm = document.getElementById("inputDoAmDat").value = ' ';
    socket.emit("Led2",'off')
    document.getElementById('min').style.background = "rgb(157, 255, 0)";
    document.getElementById('dh').src='./wateroff.png';
    console.log("Ngưỡng nhiệt độ và độ ẩm đã được tắt.");
}

function On2(){
  socket.emit("Led2", 'on')
  document.getElementById('min').style.background ="red";
  document.getElementById('dh').src='./wateron.png';
  document.getElementById("led2on").style.color = "blue";
}

function Off2(){
  socket.emit("Led2",'off')
  document.getElementById('min').style.background = "rgb(157, 255, 0)";
  document.getElementById('dh').src='./wateroff.png';
}



//-------------------------------------Hàm setup lập lịch tự bật nước----------------------
var startTime;
var endTime;
var electedDay;


function setWaterTimer() {
  alert("Đã cài đặt thời gian bơm nước");

  startTime = document.getElementById('start-time').value;
  endTime = document.getElementById('end-time').value;
  selectedDay = document.getElementById('watering-day').value;

  if (startTime && endTime) {
    var now = new Date();
    // var start = new Date(now.toDateString() + ' ' + startTime);
    // var end = new Date(now.toDateString() + ' ' + endTime);
    var selectedDateTime = getNextWateringDateTime(selectedDay, startTime, now);
    var selectedEndDateTime = getNextWateringDateTime(selectedDay, endTime, now);

    // if (start > now) {
    //   // Nếu thời gian bật nước trong tương lai, đặt hẹn giờ để bật nước
    //   var delay = start - now;
    //   setTimeout(turnOnWater, delay);
    // }

    // if (end > now) {
    //   // Nếu thời gian tắt nước trong tương lai, đặt hẹn giờ để tắt nước
    //   var delay = end - now;
    //   setTimeout(turnOffWater, delay);
    // }

    if (selectedDateTime > now) {
      var delay = selectedDateTime - now;
      setTimeout(turnOnWater, delay);
    }

    if (selectedEndDateTime > now) {
      var delay = selectedEndDateTime - now;
      setTimeout(turnOffWater, delay);
    }
  }
}

  function getNextWateringDateTime(selectedDay, selectedTime, now) {
    const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  
    if (selectedDay === 'daily') {
      const nextWateringDateTime = new Date(now.getTime());
      nextWateringDateTime.setHours(selectedTime.split(':')[0]);
      nextWateringDateTime.setMinutes(selectedTime.split(':')[1]);
      nextWateringDateTime.setSeconds(0);
      nextWateringDateTime.setMilliseconds(0);
  
      if (nextWateringDateTime.getTime() < now.getTime()) {
        nextWateringDateTime.setDate(nextWateringDateTime.getDate() + 1);
      }
  
      return nextWateringDateTime;
    } else {
      const selectedDayIndex = daysOfWeek.indexOf(selectedDay);
      const nowDayIndex = now.getDay();
      const diff = selectedDayIndex - nowDayIndex;
    
      let nextWateringDateTime = new Date(now.getTime());
      nextWateringDateTime.setDate(now.getDate() + diff);
      nextWateringDateTime.setHours(selectedTime.split(':')[0]);
      nextWateringDateTime.setMinutes(selectedTime.split(':')[1]);
      nextWateringDateTime.setSeconds(0);
      nextWateringDateTime.setMilliseconds(0);
    
      if (nextWateringDateTime.getTime() < now.getTime()) {
        nextWateringDateTime.setDate(nextWateringDateTime.getDate() + 7);
      }
    
      return nextWateringDateTime;
    }
  }

  function setOffTimer(){
    alert('Hủy lịch tưới nước');
    startTime = document.getElementById('start-time').value = ' ';
    endTime = document.getElementById('end-time').value = ' ';
    selectedDay = document.getElementById('watering-day').value = ' ';
    // // claerTimeout(startTime);
    // // claerTimeout(endTime);
    turnOffWater(); 
  }
  
  function turnOnWater() {
    // Code để bật nước
    socket.emit("Led2",'on')
    document.getElementById('min').style.background ="red";
    document.getElementById('dh').src='./wateron.png';
    console.log('Bật nước');
  }
  
  function turnOffWater() {
    // Code để tắt nước
    socket.emit("Led2",'off')
    document.getElementById('min').style.background = "rgb(157, 255, 0)";
    document.getElementById('dh').src='./wateroff.png';
    console.log('Tắt nước');
  }




