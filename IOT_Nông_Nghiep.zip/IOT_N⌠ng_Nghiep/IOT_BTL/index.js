// Gõ lệnh node index.js để bắt đầu chạy server

var express = require('express')  // Module xử lí chung
var mysql = require('mysql2')     // Module cho phép sử dụng cơ sở dữ liệu mySQL 
var mqtt = require('mqtt')        // Module cho phép sử dụng giao thức mqtt
var exportData = require('./export.js') // Require file export.js


var app = express()
var port = 6060         // Port của localhost do mình chọn

app.use(express.static("public"))
app.set("views engine", "ejs")
app.set("views", "./views")

app.get('/', function (req, res) {
    res.render('home.ejs')
})

app.get('/history.ejs', function (req, res) {
    res.render('history.ejs')
})

var server = require("http").Server(app)
var io = require('socket.io')(server)

server.listen(port, function () {
    console.log('Server listening on port ' + port) //Lắng nghe port
})


//----------------------MQTT-------------------------
//Kết nôí với MQTT sever của máy

//----------------------MQTT-------------------------
var data_mqtt = {
    host: '8203f193f4de4d2ea65abfee542d447f.s1.eu.hivemq.cloud',
    port: 8883,
    protocol: 'mqtts',
    username: 'lehiep',
    password: 'Hh29122001',
    clientId: 'serverjs2'
}

// initialize the MQTT client
var mqtt_client = mqtt.connect('mqtt://broker.hivemq.com:1883', { clientId: "serverjs1" });

// -------------Khai báo thông tin sever máy----------
// var data_mqtt={
//           broker:"//mqtt:localhost",
//           port: 1883,
// }

// var mqtt_client = mqtt.connect("mqtt://localhost");

// Khai báo topic của đèn để gửi tin 
var topic1 = "Led1";
var topic2 = "Led2";


mqtt_client.on("connect", function () {
    console.log("Connected to MQTT server " );
});

mqtt_client.on("error", function (error) {
    console.log("Can't connect" + error);
    process.exit(1)  
});

var client_topic =["sensors"];
mqtt_client.subscribe("sensors"); 

//--------Kết nối vào My SQL PHP MyAdmin or Xampp------------------------------
var con = mysql.createConnection({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: 'Hh29122001',
    database: 'data'
});


var m_time
var newTemp
var newHumi
var newLight
var newADC

//--------------------------------------------------------------------
var check = 0;

mqtt_client.on('message', function(topic, message, packet) {
    console.log("message is " + message)
    console.log("topic is " + topic)
    const objData = JSON.parse(message) // Tách dữ liệu cảm biến từ chuỗi lưu các giá trị từ cảm biến gửi lên vào các hàm ở dưới 
    if (topic == client_topic[0]) {
        check = check + 1;
        newTemp  = objData.Temperature;
        newHumi  = objData.Humidity;
        newLight = objData.Light;
        newDoam    = objData.DOAM;
        // console.log(newTemp);
        // console.log(newHumi);
        // console.log(newLight);
    }
    //---------------------------------------------CREATE TABLE ( Tạo table trên My SQL)-------------------------------------------------
        con.connect(function (err) {
        if (err) throw err;
        console.log("mysql connected");
        var sql = "CREATE TABLE IF NOT EXISTS sensor8 (ID int(10) not null primary key auto_increment, Time datetime not null, Temperature int(3) not null, Humidity int(33) not null, Light int (5) not null, Doam int(8) not null)"
        con.query(sql, function (err) {
        if (err) throw err;
        console.log("Table created");
     });
})

    
    if (check == 1) {
     
        console.log("ready to save")
        var n = new Date()
        var month = n.getMonth() + 1
        var Date_and_Time = n.getFullYear() + "-" + month + "-" + n.getDate() + " " + n.getHours() + ":" + n.getMinutes() + ":" + n.getSeconds();

        var sql = "INSERT INTO sensor8 (Time, Temperature, Humidity, Light, Doam) VALUES ('"+ Date_and_Time.toString()+"','"+ newTemp +"', '"+ newHumi + "','"+ newLight +"' ,'"+ newDoam +"')"
         con.query(sql, function (err, result) {
              if (err) throw err;
              console.log("Table inserted");
              console.log(Date_and_Time + " " + newTemp + " " + newHumi + " " + newLight + " " + newDoam + " ")
          });

        exportData(con, io);
        check = 0;
    }
})

//-------------Control devices----------------------------

 io.sockets.on('connection', function (socket) {
    console.log(socket.id + " connected")

    socket.on('disconnect', function(){
        console.log(socket.id + " disconnected")
    })

    socket.on("Led1", function (data) {
        if (data == "on") {
            console.log('Led1 đã được bật ')
            mqtt_client.publish(topic1, 'Led1 On');
        }
        else {
            console.log('Led1 đã tắt')
            mqtt_client.publish(topic1, 'Led1 Off');
        }
    })

    socket.on("Led2", function (data) {
        if (data == "on") {
            console.log('Led2 đã được bật')
            mqtt_client.publish(topic2, 'Led2 On');
        }
        else {
            console.log('Led2 đã tắt')
            mqtt_client.publish(topic2, 'Led2 Off');
        }
    })
 })

     