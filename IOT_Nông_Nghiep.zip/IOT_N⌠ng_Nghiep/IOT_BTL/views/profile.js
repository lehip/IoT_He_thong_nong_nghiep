
//----------------function bat de---------------
function ClickOn1(){
    var x =confirm('Bạn có muốn bật đèn hay không');
    if(x == true){
    socket.emit("Led1",'on')
    document.getElementById("background1").style.background="red";
    document.getElementById("myImage").src="./bongdensang.jpg";
  }
  }
  
  function ClickOff1(){
    var x =confirm('Bạn có muốn tắt đèn hay không ?'); 
    if(x==true){
    socket.emit("Led1",'off')
    document.getElementById("background1").style.background="blue";
    document.getElementById("myImage").src= "./bongden.jpg";
  }
  }
  
  function swicth(){
    var no = document.getElementById("led2on");
    if(no.checked == true){
    alert('Bạn yêu có muốn bật điều hòa không vậy ? ');
    socket.emit("Led2",'on');
    document.getElementById('min').style.background = "pink";
    document.getElementById('dh').src='./dh.png';
  }else{
    
  }
}

function switchoff(){
    var no = document.getElementById("led2on");
    if(no.checked == true){
    alert('Bạn yêu có muốn tắt điều hòa không vậy ? ');
    socket.emit("Led2",'off');
    document.getElementById('min').style.background = "red";
    document.getElementById('dh').src='./dhoff.png';
  }else{
    
  }
}

var chart = Highcharts.chart('container', {
  chart: {
      zoomType: 'xy'
  },
      title: {
      text: 'Đồ thị nhiệt độ - độ ẩm'
  },

  xAxis: [{
      categories: [],
      tickWidth: 1,
      tickLength: 20
  }],
  yAxis: [{ // Primary yAxis
      labels: {
          format: '{value}',
          style: {
              color: Highcharts.getOptions().colors[1]
          }
  },
      title: {
          text: 'Nhiệt độ (°C)',
          style: {
              color: Highcharts.getOptions().colors[1]
          }
          },
  }, { // Secondary yAxis
      title: {
          text: 'Độ ẩm(%)',
          style: {
              color: Highcharts.getOptions().colors[0]
      }
  },
      labels: {
          format: '{value}',
          style: {
              color: Highcharts.getOptions().colors[0]
          }
      },
      opposite: true
  }],
  tooltip: {
      shared: true
  },
  legend: {
      layout: 'vertical',
      align: 'left',
      x: 120,
      verticalAlign: 'top',
      y: 100,
      floating: true,
      backgroundColor:
          Highcharts.defaultOptions.legend.backgroundColor || // theme
          'rgba(255,255,255,0.25)'
  },
  series: [{
      name: 'Độ ẩm',
      type: 'column',
      yAxis: 1,
      data: [],
      tooltip: {
          valueSuffix: '%'
      },

  }, {
      name: 'Nhiệt độ',
      type: 'spline',
      data: [],
      tooltip: {
        valueSuffix: '°C'
    },
      zones: [{
          value: 10,
          color: '#ff0015',
        }, {
          value: 30,
          color: '#141107'
      }, {
          color: '#ff0015'
      }],
  }],
});

var humi = [0,0,0,0,0,0,0,0,0,0];
var temp = [0,0,0,0,0,0,0,0,0,0];


socket.on("server-send-humi_graph", function (data) {
  humi.push(data);
  humi.shift(data);
  chart.series[0].setData(data);
});

socket.on("server-send-temp_graph", function (data) {
  temp.push(data);
  temp.push(data);
  chart.series[1].setData(data);
});

socket.on("server-send-date_graph", function (data) {
  chart.xAxis[0].setCategories(data);
});





//--------------------------------------------------------------
var chart = Highcharts.chart('container', {
  chart: {
      zoomType: 'xy'
  },
  title: {
      text: 'Đồ thị nhiệt độ - độ ẩm'
  },

  xAxis: [{
      categories: [],
      tickWidth: 1,
      tickLength: 20
  }],
  yAxis: [{ // Primary yAxis
  title: {
          text: 'Nhiệt độ (°C)',
          style: {
              color: Highcharts.getOptions().colors[1]
          }
  },
      labels: {
          format: '{value}',
          style: {
              color: Highcharts.getOptions().colors[1]
          }
  },
     
  }, { // Secondary yAxis
      title: {
          text: 'Độ ẩm (%)',
          style: {
              color: Highcharts.getOptions().colors[0]
          }
      },
      labels: {
          format: '{value}',
          style: {
              color: Highcharts.getOptions().colors[0]
          }
      },
      opposite: true
  }],
  legend: {
      layout: 'vertical',
      align: 'left',
      x: 60,
      verticalAlign: 'top',
      y: 50,
      floating: true,
      backgroundColor:
          Highcharts.defaultOptions.legend.backgroundColor || // theme
          'rgba(255,255,255,0.25)'
  },
  series: [{
      name: 'Nhiệt độ',
      type: 'column',
      data: [],
      tooltip: {
          valueSuffix: '°C'
      },

  }, {
    name: 'Độ ẩm',
    type: 'column',
    yAxis: 1,
    data: [],
    tooltip: {
        valueSuffix: '%'
    }
  }],
});











